const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType, ActivityType } = require("discord.js")
const { QuickDB } = require('quick.db');
const db = new QuickDB();

module.exports = {
    name: "setstatus",
    description: "『 DEVELOPER 』Configure meu status.",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            type: ApplicationCommandOptionType.String,
            name: "status",
            description: "Qual estilo você deseja aplicar (online, dnd, idle, invisible)?",
            required: true,
            choices: [
                { name: 'Disponível', value: 'online' }, { name: 'Não pertubar', value: 'dnd' },
                { name: 'Ausente', value: 'idle' }, { name: 'Invísivel', value: 'invisible' },
            ],
        },
        {
            type: ApplicationCommandOptionType.String,
            name: "descrição",
            description: "Qual será a descrição do status?",
            required: true,
        },
        {
            type: ApplicationCommandOptionType.String,
            name: "tipo",
            description: "Qual activity type queres??",
            required: true,
            choices: [
                { name: 'Assistindo', value: 'assistindo' }, { name: 'Competindo', value: 'competindo' },
                { name: 'Jogando', value: 'jogando' }, { name: 'Escutando', value: 'escutando' },
                { name: 'Streaming', value: 'streaming' }, { name: 'Ativar Atv', value: 'on'}, { name: 'Desativar Atv', value: 'off'}
            ],
        },
        {
            type: ApplicationCommandOptionType.String,
            name: "url",
            description: "Acaso escolheste Streaming, qual é o link?",
            required: false,
        },
    ],

    run: async (client, interaction) => {

        if (interaction.user.id !== '430502315108335617') return interaction.reply({ content: `Apenas o meu dono pode utilizar este comando!`, ephemeral: true })

        let status = interaction.options.getString("status");
        let desc = interaction.options.getString("descrição");
        let tipo = interaction.options.getString("tipo");

        let apucas = {
            'assistindo': ActivityType.Watching, 'competindo': ActivityType.Competing,
            'jogando': ActivityType.Playing, 'escutando': ActivityType.Listening,
            'streaming': ActivityType.Streaming,
        }
        let estado = {
            'online': 'Disponível', 'dnd': 'Não Pertubar',
            'idle': 'Ausente', 'invisible': 'Invísivel'
        }
        switch (tipo) {
            case 'streaming': {
                let link = interaction.options.getString("url");

                if (!link) {
                    return interaction.reply(`**VOCÊ NÃO CITOU UM LINK PARA PÔR!**`)
                }

                client.user.setActivity({
                    name: desc,
                    type: ActivityType.Streaming,
                    url: link
                });
                client.user.setStatus(status)
            } break;

            case 'invisible': {
                client.user.setStatus(status)
            } break;

            default: {
                client.user.setActivity(desc, {
                    type: apucas[tipo]
                });
                client.user.setStatus(status)
            } break;
        }

        let avatar = client.user.displayAvatarURL({ dynaimc: true })
        let embed = new EmbedBuilder()
            .setColor('Purple')
            .setThumbnail(avatar)
            .setTitle(`NOVO STATUS DEFINIDO!`)
            .setDescription(`**- 📃 Descrição definida: **\`\`\`${desc}\`\`\`\n\n**- 🌐 Status definido: **\`\`\`${estado[status]}\`\`\``)
            .setFooter({ text: client.user.username, iconURL: avatar })

        interaction.reply({ embeds: [embed] })
    }
}