const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js")
const { QuickDB } = require('quick.db')
const db = new QuickDB();
// const emojis = require('../../emojis.json')

module.exports = {
    name: "tdu-users", // Coloque o nome do comando
    description: "『 DEVELOPER 』Vê quem concordou com os termos de uso.", // Coloque a descrição do comando
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'user',
            description: `Procura se o usuário leu os termos de uso`,
            type: ApplicationCommandOptionType.User,
        },
    ],

    run: async (client, interaction) => {
        try {
            
            if (interaction.user.id !== '430502315108335617') return interaction.reply(`**VOCÊ NÃO É MEU DONO PARA UTILIZAR ESSE COMANDO!**`)
            let users = await db.get(`Users_termosLido.users`)
            if (!users) await db.set(`Users_termosLido`, {
                users: []
            })
            let usuarios = [];
    
            let nico = interaction.options.getUser('user')
            if(nico) {
                if(users.includes(nico.id)) {interaction.reply({ephemeral: true, content: `**✅ | O USUÁRIO LEU E CONCORDOU COM OS TERMOS DE USO!**`})} else {
                    interaction.reply({ephemeral: true, content: `**❌ | O USUÁRIO NÃO CONCORDOU COM OS TERMOS DE USO**`})
                }
                return
            }
    
            for (let index = 0; index < users.length; index++) {
                usuarios.push(`<@${users[index]}> (${users[index]})`)
            }
    
            const embed = new EmbedBuilder()
                .setTitle(`USUÁRIOS QUE CONCORDARAM DOS TERMOS DE USO: `)
                .setDescription(`${usuarios.join(', ')}`)
    
            interaction.reply({ embeds: [embed], ephemeral: true })
        } catch (error) {
            console.log(`ERRO NO TDUUSERS:`, error);
        }
    }
}