const { EmbedBuilder, ApplicationCommandType, ModalBuilder, TextInputBuilder, TextInputStyle,
   ActionRowBuilder, ApplicationCommandOptionType, ChannelType, UserFlags } = require("discord.js")
const ms = require('ms')
const { QuickDB } = require('quick.db');
const db = new QuickDB();
const config = require("../../config.json");
const { isNullOrUndefined } = require("util");
const wait = require('node:timers/promises').setTimeout;
const util = require('node:util');

module.exports = {
  name: "quick-command", // Coloque o nome do comando
  description: "『 DEVELOPER 』A fim de testes ao bot.", // Coloque a descrição do comando
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: 'string',
      description: 'Informe o motivo.',
      type: ApplicationCommandOptionType.String,
      required: true
    }
  ],

  run: async (client, interaction) => {

    if(interaction.user.id !== '430502315108335617') return interaction.reply(`**VOCÊ NÃO É MEU DONO PARA UTILIZAR ESSE COMANDO!**`)
    try {
      let allServers = client.guilds.cache.map(guild => {
        let todosOsServidores = []
        todosOsServidores.push(`${guild.name} (${guild.id})`)
        return todosOsServidores
      })
      interaction.reply(allServers.join(`,\n`))
  } catch (error) {
  interaction.reply({embeds: [
         new EmbedBuilder()
        .setDescription(`ERR: \n\`\`\`${error}\`\`\``)
      ]})
    }

   
  }
}
/* const modal = new ModalBuilder()
 .setCustomId('modal')
 .setTitle('O CORE É LINDOOOO')

 const tempoSorteio = new TextInputBuilder()
 .setCustomId('sorteio')
 .setLabel('Quanto terá o tempo do sorteio?')
 .setStyle(TextInputStyle.Short)
 .setRequired(true)
 .setPlaceholder('Tempo: s/seconds, m/min/minutes, h/hour/hours/ d/day/days')
 .setValue('tempoSorteio')
 const tempoClaim = new TextInputBuilder()
 .setCustomId('claim')
 .setLabel('Quanto terá o tempo de claim?')
 .setStyle(TextInputStyle.Short)
 .setRequired(true)
 .setPlaceholder('Tempo: s/seconds, m/min/minutes, h/hour/hours/ d/day/days')
 .setValue('tempoClaim')
 
 modal.addComponents(
   new ActionRowBuilder().addComponents(tempoSorteio),
   new ActionRowBuilder().addComponents(tempoClaim)
   )*/
   

 //await interaction.showModal(modal)
   /*let nI = options.getInteger('número-inicial')
   let nF = options.getInteger('número-final')
  
   function gerarNumeroAleatorio(min, max) {
  const randomDecimal = Math.random();
  const valorAleatorio = min + Math.floor(randomDecimal * (max - min + 1));
  
  return valorAleatorio;
  }
  
  const numeroAleatorio = gerarNumeroAleatorio(nI, nF);
  await interaction.reply(numeroAleatorio.toString())*/

/*
const dataSorteio = moment().add(1, 'minute').add(15, 'second')

      function exibirTempoRestante() {
        const agora = moment()
        const diff = dataSorteio.diff(agora)
        const duração = moment.duration(diff)
        const d = duração.asMilliseconds()
  
        const dias = duração.days();
        const horas = duração.hours()
        const minutos = duração.minutes()
        const segundos = duração.seconds()

        let time = '';

        dias > 0 ? time = `${dias} dia${dias > 1 ? 's' : ''}` : null;
        horas > 0 ? time = `${horas} hora${horas > 1 ? 's' : ''}` : null;
        minutos > 0 ? time = `${minutos} minuto${minutos > 1 ? 's' : ''}` : null;
        d < ms('1m') ? time = `${segundos} segundo${segundos > 1 ? 's' : ''}` : null

        return time
      }

        interaction.reply(`Exibindo tempo restante...`)
       let Alvaro = setInterval(() => {
          interaction.editReply(`TEMPO RESTANTE: ${exibirTempoRestante()}`)
          if(exibirTempoRestante() == '0 segundo') clearInterval(Alvaro)
        }, 1000);
*/

/**
 * // const usuário = interaction.guild.members.cache.get(User.id)
        let badgesUser = User.flags.toArray() || [];
        if(User.tag.endsWith('0')) badgesUser.push('NoTag')
        if(badgesUser.length == 0) badgesUser.push('NoBadges')
        User.bot ? badgesUser.unshift('Bot') : badgesUser.unshift('User')
      const User = interaction.options.getUser('usuário');
        const userData = await fetch(`https://serenys.xyz/api/discord/users/${User.id}`);
        const api = await userData.json();
        console.log(api)

        const transformarBadges = {
          ActiveDeveloper: "<:ActiveDeveloper:1134126319513378938>",
          BugHunterLevel1: "<:BugHunter1:1134126407321145386>",
          BugHunterLevel1: "<:BugHunter2:1134126588846424236>",
          CertifiedModerator: "<:CertifiedModerator:1134126478934691861>",
          HypeSquadOnlineHouse1: "<:Bravery:1134126357635399752>",
          HypeSquadOnlineHouse2: "<:Brilliance:1134126378653061120>",
          HypeSquadOnlineHouse3: "<:Balance:1134126339767672883>",
          Hypesquad: "<:Hypesquad:1134126567900057740>",
          Partner: "<:Partner:1134126685982298234>",
          PremiumEarlySupporter: "<:EarlySupporter:1134126528632983552>",
          Staff: "<:DiscordStaff:1134126501672009810>",
          VerifiedBot: "<:VerifiedBot:1134126723898818631>",
          VerifiedDeveloper: "<:VerifiedBotDeveloper:1134126741380669440>",
          SlashCommands: "<:SlashCommands:1134126705699721306>",
          Nitro: "<:Nitro:1134126667372167168>",
          Bot: "<:Bot:1144642733290561596>",
          User: "<:User:1144643307922804807>",
          NoTag: "<:Knownas:1134126642831306812>",
          Dono: "<:Dono:1144643357470109819>",
          NoBadges: "Nada!"
      }

      if (data.public_flags_array) {

          await Promise.all(data.public_flags_array.map(async badge => {
              if (badge === 'NITRO') badgesUser.push('Nitro');
              console.log(badge)
          }));

      }
      if(User.bot) {
        const botFetch = await fetch(
          `https://discord.com/api/v10/applications/${User.id}/rpc`
        );

      let json = await botFetch.json();
      let flagsBot = json.flags;

      const gateways = {
          APPLICATION_COMMAND_BADGE: 1 << 23,
      };

      let arrayFlags = [];
      
      for (let i in gateways) {
          const bit = gateways[i];
          if ((flagsBot & bit) === bit) arrayFlags.push(i);
      }

      if (arrayFlags.includes('APPLICATION_COMMAND_BADGE')) {
        badgesUser.push(`SlashCommands`);
      } 
      }
        
      await interaction.reply(`Badges: ${
        badgesUser.map((flag) => transformarBadges[flag]).join(', ')
      }`)
 */