const { EmbedBuilder, ApplicationCommandType, StringSelectMenuBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle } = require("discord.js")
const { QuickDB } = require('quick.db')
const db = new QuickDB();
const emoji = {
  'disponivel': "✅",
  'manutencao': "⏳",
  'indisponivel': "☁️",
  'banido': "💀",
  'wave': "<:GuraWave:1135637456927076482>",
  'permrole': '🛡️'
}
const emojis = require('../../emojis.json')
const ms = require('ms')

module.exports = {
  name: "config-ajuda", // Coloque o nome do comando
  description: "『 DEVELOPER 』Configura o comando /help-ajuda", // Coloque a descrição do comando
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (interaction.user.id !== '430502315108335617') return interaction.reply(`**VOCÊ NÃO É MEU DONO PARA UTILIZAR ESSE COMANDO!**`)
    let p = '\u276F';
    let s = '\u27A5';

    let embedInicial = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setDescription(`**${emoji.wave} Olá, ${interaction.user}. Seja bem-vindo(a) ao meu painel de configurações de comandos!\n\n**`)
      .addFields(
        { name: '\`Legenda emojis:\`', value: `[${emoji.disponivel}] \u21D2 Comando disponível.\n[${emoji.manutencao}] \u21D2 Comando em manutenção/em desenvolvimento.\n[${emoji.indisponivel}] \u21D2 Comando indisponível.\n[${emoji.banido}] \u21D2 Comando banido (com motivo anexado)\n[${emoji.permrole}] \u21D2 Comando que é necessário a permRole para funcionar.` },
        { name: '\u200B', value: '\u0020' },
        { name: '\`Legenda parâmetros:\`', value: `\u276F \`Comando principal\`\n\u27A5 \`Subcomando\``, inline: true },
        { name: '\u0020', value: `\u0020`, inline: true },
        { name: '\`Dica:\`', value: '- _Basta usar o menu de seleção para ver as categorias de comandos que tenho no momento!_', inline: true },
      )

    let embedBot = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: bot`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 1/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num5}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.disponivel}] ${p} \`\`Bot-info:\`\` **Veja minhas informações.**\n\n` +
        `[${emoji.disponivel}] ${p} \`\`Help-ajuda:\`\` **Ei, é o comando que está usando!**\n\n` +
        `[${emoji.disponivel}] ${p} \`\`Ping:\`\` **Veja o meu ping.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Reportar-bug:\`\` **Você identificou algum bug em mim? Use esse comando para enviar ao meu criador e ele reparar o bug!**\n\n` +
        `[${emoji.disponivel}] ${p} \`\`Say:\`\` **Faça eu falar algo!**\n\n`
      )

    let embedBrincadeiras = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: brincadeiras`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 2/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num3}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.indisponivel}][${emoji.permrole}] ${p} \`\`Contagem:\`\` **Começa uma contagem numeral no canal atual.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Cara-coroa:\`\` **Lança uma moeda que dá cara ou coroa.**\n\n` +
        `[${emoji.disponivel}] ${p} \`\`Pedra-papel-tesoura:\`\` **Começa um jogo de pedra, papel e tesoura.**\n\n`
      )

    let embedDiversos = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: diversos`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 3/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num3}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.disponivel}] ${p} \`\`Afk:\`\` **Ativa seu modo AFK! (quando digitar algo no chat, automáticamente irá desativar).**\n\n` +
        `[${emoji.manutencao}] ${p} \`\`Avaliar-staff:\`\` **Sempre tem aquele staff gente fina, né? Avalie um staff dando até 5 estrelas!**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Div:\`\` **Divulgue o que quer no canal de divulgações!**\n\n`
      )

    let embedInfo = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: info`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 4/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num5}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.indisponivel}] ${p} \`\`Channel-info:\`\` **Fornece as informações sobre dado canal (texto/voz).**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Server-info:\`\` **Fornece as informações sobre a Família Smurf.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`User-info:\`\` **Fornece as informações sobre algum membro/bot.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Emoji-info:\`\` **Fornece as informações sobre algum emoji.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Role-info:\`\` **Fornece as informações sobre algum cargo.**\n\n`
      )

    let embedSorteio = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: sorteio`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 5/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num3}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.disponivel}][${emoji.permrole}] ${p} \`\`Sorteio:\`\` **Começa um sorteio.**\n` +
        `[${emoji.indisponivel}][${emoji.permrole}] ${s} \`\`Reroll:\`\` **Rolete novos ganhadores do último sorteio.**\n` +
        `[${emoji.indisponivel}][${emoji.permrole}] ${s} \`\`Edit:\`\` **Edita o último sorteio.**\n`
      )

    let embedStaff = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: staff`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 6/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num1}${emojis.num3}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.indisponivel}] ${p} \`\`Anti-raid:\`\` **Ativa o sistema de anti-raid.**\n\n` +
        `[${emoji.disponivel}] ${p} \`\`Clear:\`\` **Limpa até 100 mensagens em algum canal.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Config-staff:\`\` **Registra e configura o cargo de Staff.**\n\n` +
        `[${emoji.disponivel}][${emoji.permrole}] ${p} \`\`Lock-unlock:\`\` **Abre ou fecha um canal.**\n\n` +
        `[${emoji.indisponivel}][${emoji.permrole}] ${p} \`\`Lock-down:\`\` **Fecha todos os canais da Família Smurf.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`On-offlist:\`\` **O Staff fica online/offline na lista.**\n\n` +
        `[${emoji.disponivel}] ${p} \`\`Permrole-config:\`\` **Configura as permroles.**\n` +
        `[${emoji.disponivel}] ${s} \`\`Permrole-list:\`\` **Fornece a lista das permroles ativas.**\n` +
        `[${emoji.disponivel}] ${s} \`\`Permrole-set:\`\` **Registra ou exclui uma permrole setada.**\n` +
        `[${emoji.disponivel}] ${s} \`\`Permrole-delete-all:\`\` **Apaga todas as permroles setadas.**\n\n` +
        `[${emoji.indisponivel}][${emoji.permrole}] ${p} \`\`Slowmode:\`\` **Ativa/Desativa o modo slowmode (cooldown no chat).**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Sos:\`\` **Solicita auxilio da Staff de imediato (cooldown do comando: 30 minutos).**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Staff-list:\`\` **Mostra todos Staff's listados como online naquele momento.**\n\n`
      )

    let embedUtilidade = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda, categoria: utilidade`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: `/help-ajuda \u2023 Página 7/7`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })
      .setColor('#3460FF')
      .setTitle(`- Total de comandos: ${emojis.num4}\n`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `[${emoji.manutencao}] ${p} \`\`Enquete:\`\` **Inicia uma enquete.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Gerador-de-senha:\`\` **Gera uma senha aleatória.**\n\n` +
        `[${emoji.disponivel}] ${p} \`\Gerar-numero-aleatorio:\`\` **Gera uma número aleatória.**\n\n` +
        `[${emoji.manutencao}] ${p} \`\`Lembrete-remind:\`\` **Cria um lembrete.**\n\n` +
        `[${emoji.indisponivel}] ${p} \`\`Report:\`\` **Reporta um usuário.**\n\n`
      )

    let embedEnd = new EmbedBuilder()
      .setAuthor({ name: `Menu de ajuda`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
      .setDescription(
        `**${emoji.wave} Olá, ${interaction.user}. O tempo de usar o help acabou! Utilize novamente o comando se deseja continuar navegando.\n\n**`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setColor('#3460FF')
      .setFooter({ text: `/help-ajuda`, iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 2048 }) })

    let buttonInicial = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("voltar")
        .setEmoji("↩️")
        .setStyle(ButtonStyle.Success)
    );

    let buttonCategorias = new ActionRowBuilder().addComponents(

      new ButtonBuilder()
        .setCustomId('bots')
        .setEmoji('🤖')
        .setLabel('Bots')
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId('brincadeiras')
        .setEmoji('🕹️')
        .setLabel('Brincadeiras')
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId('diversos')
        .setEmoji('⭐')
        .setLabel('Diversos')
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId('info')
        .setEmoji('📶')
        .setLabel('Info')
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId('sorteio')
        .setEmoji('🍀')
        .setLabel('Sorteio')
        .setStyle(ButtonStyle.Primary),
    )
    let buttonCategorias2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('staff')
        .setEmoji('👮‍♂️')
        .setLabel('Staff')
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId('utilidade')
        .setEmoji('🪛')
        .setLabel('Utilidade')
        .setStyle(ButtonStyle.Primary),
    )

    /*let painel = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("painel_ticket")
        .setPlaceholder("Escolha a página!")
        .addOptions(
          {
            label: "Página 1/7",
            description: "PÁGINA SOBRE BOT [5]",
            value: "pg1"
          },
          {
            label: "Página 2/7",
            description: "PÁGINA SOBRE BRINCADEIRAS [3]",
            value: "pg2"
          },
          {
            label: "Página 3/7",
            description: "PÁGINA SOBRE DIVERSOS [3]",
            value: "pg3"
          },
          {
            label: "Página 4/7",
            description: "PÁGINA SOBRE INFO [5]",
            value: "pg4"
          },
          {
            label: "Página 5/7",
            description: "PÁGINA SOBRE SORTEIO [3]",
            value: "pg5"
          },
          {
            label: "Página 6/7",
            description: "PÁGINA SOBRE STAFF [13]",
            value: "pg6"
          },
          {
            label: "Página 7/7",
            description: "PÁGINA SOBRE UTILIDADE [4]",
            value: "pg7"
          }
        )
    );*/

   interaction.reply({ embeds: [embedInicial], components: [buttonCategorias, buttonCategorias2] })

    const coll = await interaction.channel.awaitMessageComponent({
      filter: (i) => i.user.id === interaction.user.id,
      time: ms('1h'),
    })

      console.log(coll) 
    
  }
}