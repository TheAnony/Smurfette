const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ComponentType, ChannelType, ApplicationCommandType, ApplicationCommandOptionType } = require('discord.js');
const emojis = require('../../emojis.json')

module.exports = {
    name: 'embed-creator',
    description: "Crie uma embed personalizável",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'channel',
            description: `Escolha o canal que será enviado a embed`,
            type: ApplicationCommandOptionType.Channel,
            channelType: [ChannelType.GuildText]
        }
    ],
    run: async (client, interaction) => {
        if(interaction.user.id !== '430502315108335617');
        const canal = interaction.guild.channels.cache.get(
            interaction.options.get('channel')?.value || interaction.channel.id
        )

        let opcoesEscolhidas = [];
        let authorText = ''
        let authorURL = ''
        let authorIcon = ''
        let footerText = ''
        let footerIcon = ''

        if (!canal) return interaction.reply({ ephemeral: true, content: `${emojis.err} | Canal inválido!` })

        const frases = [
            "Imagine o impossível e crie o extraordinário.",
            "A imaginação é o ponto de partida para criar algo novo.",
            "Criar é transformar sonhos em realidade.",
            "A imaginação é o combustível da criatividade.",
            "Crie com paixão e veja sua imaginação ganhar vida.",
            "Imagine além dos limites e crie sem restrições.",
            "A criação é a expressão da mente em ação.",
            "A imaginação é a chave para desbloquear novas possibilidades.",
            "Criar é dar forma aos pensamentos e dar vida às ideias.",
            "Imagine o futuro e crie um caminho para alcançá-lo.",
            "A criatividade nasce da capacidade de imaginar o inimaginável.",
            "Crie com ousadia e deixe sua marca no mundo.",
            "A imaginação é a ponte entre o que é e o que pode ser.",
            "Criar é dar asas à imaginação e voar além das fronteiras.",
            "Imagine, sonhe, crie - o poder está em suas mãos.",
            "A criação é a manifestação do pensamento em forma tangível.",
            "A imaginação é a faísca que acende a chama da criação.",
            "Crie com autenticidade e deixe sua marca única.",
            "Imagine-se no lugar dos outros e crie empatia.",
            "A criação é o resultado de um processo contínuo de imaginar e reinventar.",
            `O único limite é a imaginação!`
        ];

        let numMessage = Math.floor(Math.random() * frases.length)

        const embedPrincipal = new EmbedBuilder()
            .setTitle(`Criador de Embed`)
            .setDescription(`Selecione uma opção no menu para editar!`)
            .setColor('Aqua')

        let embedBuilder = new EmbedBuilder()
            .setDescription(`\"${frases[numMessage]}\"`)

        interaction.reply({
            embeds: [embedPrincipal, embedBuilder], components: [
                new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId(`embed.builder`)
                        .setPlaceholder(`Ferramentas de criação`)
                        .addOptions(
                            {
                                label: `Author`,
                                value: `author`
                            },
                            {
                                label: `Icon Author`,
                                value: `icon.author`
                            },
                            {
                                label: `Url Author`,
                                value: `url.author`
                            },
                            {
                                label: `Url`,
                                value: `url`
                            },
                            {
                                label: `Title`,
                                value: `title`
                            },
                            {
                                label: `Description`,
                                value: `description`
                            },
                            {
                                label: `Footer`,
                                value: `footer`
                            },
                            {
                                label: `Icon footer`,
                                value: `footer.icon`
                            },
                            {
                                label: `Color`,
                                value: `color`
                            },
                            {
                                label: `Thumbnail`,
                                value: `thumbnail`
                            },
                            {
                                label: `Image`,
                                value: `image`
                            },
                            {
                                label: `Timestamp`,
                                value: `timestamp`
                            }
                        )
                ),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`embed.creator.send`)
                        .setLabel(`Enviar`)
                        .setEmoji(`📨`)
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId(`embed.creator.restart`)
                        .setLabel(`Resetar`)
                        .setEmoji(`🔁`)
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId(`embed.creator.save`)
                        .setLabel(`Salvar`)
                        .setEmoji(`📩`)
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId(`embed.creator.end`)
                        .setLabel(`Finalizar`)
                        .setEmoji(`1157663872220680212`)
                        .setStyle(ButtonStyle.Danger),
                )
            ]
        });

        const coletorDoMenu = interaction.channel.createMessageComponentCollector({
            type: ComponentType.StringSelect,
            filter: i => i.user.id === interaction.user.id
        });

        coletorDoMenu.on('collect', async (i) => {
            if (!i.values) return;
            const id = i.values[0];

            switch (id) {
                case 'author': {
                    i.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`Por favor, digite o nome do autor da embed!`)
                                .setColor('Yellow')
                                .setFooter({ text: `Digite \"cancelar\" para cancelar.` })
                        ], ephemeral: true
                    }).catch((err) => { console.log(`ERRO NA CRIAÇÃO DE EMBED (author):`, err) });

                    const filter = (m) => m.author.id === i.user.id;

                    await interaction.channel.awaitMessages({
                        filter: filter,
                        max: 1
                    }).then(async (received) => {
                        received.first().delete().catch((err) => { console.log(`ERRO NA CRIAÇÃO DE EMBED (author):`, err) })


                        const mensagem = received.first().content.substr(0, 256).toLowerCase();

                        if (mensagem === 'cancelar') {
                            return i.editReply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`Cancelado!`)
                                        .setColor('Red')
                                ]
                            })
                        };

                        embedBuilder.setAuthor({ name: mensagem });

                        // console.log(`ERRO NA CRIAÇÃO DE EMBED (author):`, err)

                        i.editReply({
                            content: `${emojis.check} | O  **author** Foi adicionado com sucesso.`,
                            embeds: [],
                            ephemeral: true
                        });

                        authorText = mensagem

                        interaction.editReply({ embeds: [embedPrincipal, embedBuilder] }).catch(() => { });
                    })

                } break;
                case 'icon.author': {
                    i.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`Por favor, digite a URL para o icon do autor!`)
                                .setColor('Yellow')
                                .setFooter({ text: `Digite \"cancelar\" para cancelar.` })
                        ], ephemeral: true
                    }).catch((err) => { console.log(`ERRO NA CRIAÇÃO DE EMBED (author):`, err) });

                    const filter = (m) => m.author.id === i.user.id;

                    await interaction.channel.awaitMessages({
                        filter: filter,
                        max: 1
                    }).then(async (received) => {
                        received.first().delete().catch((err) => { console.log(`ERRO NA CRIAÇÃO DE EMBED (author):`, err) })


                        const iconMensagem = received.first().content.substr(0, 256).toLowerCase();

                        if (iconMensagem === 'cancelar') {
                            return i.editReply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`Cancelado!`)
                                        .setColor('Red')
                                ]
                            })
                        };
                        console.log(iconMensagem);

                        authorText == '' ? embedBuilder.setAuthor({  name: `Um author em texto seria bom, né?`, iconURL: iconMensagem }) : 
                        embedBuilder.setAuthor({name: authorText, iconURL: 'https://cdn.discordapp.com/avatars/784054579355451423/1522624efcae41279b0ae39934ee2093.png?size=2048'});


                        // console.log(`ERRO NA CRIAÇÃO DE EMBED (author):`, err)

                        i.editReply({
                            content: `${emojis.check} | O  **icon author** Foi adicionado com sucesso.`,
                            embeds: [],
                            ephemeral: true
                        });

                        opcoesEscolhidas.push(`author`)

                        interaction.editReply({ embeds: [embedPrincipal, embedBuilder] }).catch(() => { });
                    })
                } break;
                case 'url.author': { } break;
                case 'title': { } break;
                case 'description': { } break;
                case 'color': { } break;
                case 'url': { } break;
                case 'footer': { } break;
                case 'icon.footer': { } break;
                case 'image': { } break;
                case 'thumbnail': { } break;
                case 'timestamp': { } break;

                default: break;
            }
        })
    }
}

/* function isLink(link) {
    const regexDoLink = /https?:\/\/.*\.(a?png|avif|bmp|gif|j(f?if|p(e|g|eg))|svg|tiff?|webp)(\?.*)?/i

    return regexDoLink.test(link)
}

function isHex(hegexInserido) {

    const regexColor = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
    return regexColor.test(hegexInserido)
}

function isAnURLValid (url) {
    try {
        new URL(url);
        return true
    } catch (_) {
        return false
    }
} */